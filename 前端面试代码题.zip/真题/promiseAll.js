/* promise.all，如果有一个函数失败了立即返回，否则等待所有函数结束后一次返回所有结果 */
export function myPromiseAll(promises) {
  return new Promise((resolve, reject) => {
    if (!promises.length) {
      resolve([]);
    }
    let successCount = 0;
    const results = new Array(promises.length);
    promises.forEach((item, index) => {
      Promise.resolve(item)
        .then((res) => {
          successCount++;
          results[index] = res;
          if (successCount === promises.length) {
            resolve(results);
          }
        })
        .catch((err) => {
          reject(err);
        });
    });
  });
}

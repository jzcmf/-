/*
 * @Desc: 
 * @Author: SR
 * @Date: 2025-11-27 10:49:19
 */
//双指针写法
const isSubsequence=(A,B)=>{
    if(A.length===0) return true
    let i=0;
    for(let j=0;j<B.length&&i<A.length;j++){
        if(A[i]===B[j]) i++;
    }
    return i===A.length
}
//使用内置方法计算 indexOf(目标，开始查找的下标)
const isSubsequence2=(A,B)=>{
    if(A.length===0) return true
    let startIndex=0
    for(let x of A){
        startIndex=B.indexOf(x,startIndex)
        if(startIndex===-1) return false
        startIndex++
    }
    return true
}
console.log(isSubsequence([2,4],[1,2,3,4,4,6]));

/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-01-21 09:51:41
 */
function arrayToTree(list) {
  const arrMap={}
  const result=[]
  list.forEach((element) => {
    arrMap[element.id]={...element,children:[]}
  });
  list.forEach(ltm=>{
    if(!ltm.parentId){
        result.push(arrMap[ltm.id])
    }
    else{
        arrMap[ltm.parentId].children.push(arrMap[ltm.id])
    }
  })
  return result
}
const list = [
  { id: 1, name: '部门 A', parentId: 0 },
  { id: 2, name: '部门 B', parentId: 0 },
  { id: 3, name: '小组 A-1', parentId: 1 },
  { id: 4, name: '小组 A-2', parentId: 1 },
  { id: 5, name: '小组 B-1', parentId: 2 },
  { id: 6, name: '工位 A-1-1', parentId: 3 }
];
console.log(arrayToTree(list));

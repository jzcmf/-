/*
 * @Desc:实现二叉树的层序遍历
 * @Author: SR
 * @Date: 2025-12-17 10:25:43
 */
function levelTree(root) {
  let result = [];
  const dfs = (node, level) => {
    if (!node) return;
    if (result.length === level) {
      result.push([]);
    }
    result[level].push(node.value);
    dfs(node.left, level + 1);
    dfs(node.right, level + 1);
  };
  dfs(root, 0);
  return result;
}
//广度优先-bfs
function levelTreeByBfs(root) {
  if (!root) return [];
  const result = [];
  const queue = [root];
  while (queue.length) {
    const currentLevelSize = queue.length;//记录每层有几个点
    const currentLevelValues = [];
    for (let i = 0; i < currentLevelSize; i++) {
      let node = queue.shift();
      currentLevelValues.push(node.val);
      if (node.left) {
        queue.push(node.left);
      }
      if (node.right) {
        queue.push(node.right);
      }
    }
    result.push(currentLevelValues);
  }
  return result;
}

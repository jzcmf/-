/*
 * @Desc:
 * @Author: SR
 * @Date: 2025-11-27 09:55:29
 */
/* 
富途一面：
// 实现一个 Add 函数，运算只能通过调用 expensiveCall 实现，
//    注意：
//    1. expensiveCall 是一个昂贵的异步调用。
//    2. 就示例及结合你的方案，给出调用次数、耗时评估
//    更多要求：
//    1. 所有操作应尽快的完成
//    2. 应该考虑尽可能少调用 expensiveCall 。

const expensiveCall = async (a, b) => new Promise(resolve => {
  console.log("debugger call remote", a, b)
  setTimeout(() => resolve(a + b), 1000)
})

add([1, 2, 1, 2, 1, 2, 3]).then(result => { 
  // ...
})
*/
const expensiveCall = async (a, b) =>
  new Promise((resolve) => {
    console.log("debugger call remote", a, b);
    setTimeout(() => resolve(a + b), 1000);
  });
const getKey = (a, b) => {
  return a > b ? `${a},${b}` : `${b},${a}`;
};
const add = async (nums) => {
  if (nums.length < 2) return nums[0] ?? 0;

  const addMap = new Map();//用于缓存计算过的数字组

  const addTwo =  (a, b) => {
    const key = getKey(a, b);
    if (!addMap.has(key)) {
      addMap.set(key, expensiveCall(a, b));
    }
    return addMap.get(key);
  };
  let current = [...nums];
  while (current.length > 1) {
    const promiseArr = [];
    const nextRound = [];
    for (let i = 0; i < current.length; i += 2) {
      if (i + 1 < current.length) {
        promiseArr.push(addTwo(current[i], current[i + 1]));
      } else {
        nextRound.push(current[i]);
      }
    }
    const result = await Promise.all(promiseArr);
    current = [...result, ...nextRound];
  }
  return current[0];
};

add([1, 2, 1, 2, 1, 2, 3]).then((result) => {
  console.log(result, "i am done");
});

/*
 * @Desc:对象扁平化
 * @Author: SR
 * @Date: 2025-12-17 10:25:43
 */
var entry = {
  a: {
    b: {
      c: {
        dd: "abcdd",
      },
    },
    d: {
      xx: "adxx",
    },
    e: "ae",
  },
};
function objTransform(obj, prevKey = null, result = {}) {
  for (let key in obj) {
    let fullKey = prevKey ? `${prevKey}.${key}` : key;
    if (typeof obj[key] === "object" && obj[key] !== null) {
      objTransform(obj[key], fullKey, result);
    } else {
      result[fullKey] = obj[key];
    }
  }
  return result;
}
console.log(objTransform(entry, null));

function LST(list) {
  const n = list.length;
  let maxLen = 0;
  if (!n) return 0;
  const dp = new Array(n).fill(1);
  for (let i = 1; i < n; i++) {
    for (let j = 0; j < i; j++) {
      if (list[i] > list[j]) {
        dp[i] = Math.max(dp[i], dp[j] + 1);
      }
    }
    maxLen = Math.max(maxLen, dp[i]);
  }
  return maxLen;
}
let len=LST([-1,2,6,3,4,8,9])
console.log(len);


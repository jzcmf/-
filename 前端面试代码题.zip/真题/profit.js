/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-01-22 14:26:14
 */
function getMaxProfit(list) {
  let minPrice = Infinity;
  let maxProfit = 0;
  list.forEach((item, index) => {
    if (item < minPrice) {
      minPrice = item;
    } else if (item - minPrice > maxProfit) {
      maxProfit = item - minPrice;
    }
  });
  return maxProfit;
}
// const prices = [7, 1, 5, 3, 6, 4];
// console.log("最大收益为:", getMaxProfit(prices)); // 输出: 5 (在1买入，6卖出)

function getTotalMaxProfit(list) {
  let total = 0;
  for (let i = 1; i < list.length; i++) {
    if (list[i] > list[i - 1]) {
      total += list[i] - list[i - 1];
    }
  }
  return total;
}
// const prices = [7, 1, 5, 3, 6, 4];
// console.log("最大收益为:", getTotalMaxProfit(prices)); // 输出:7

function getMaxProfitByTwice(list) {
  let buy1 = -list[0];
  let sell1 = 0;
  let buy2 = -list[0];
  let sell2 = 0;
  for (let i = 1; i < list.length; i++) {
    buy1 = Math.max(-list[i], buy1);
    sell1 = Math.max(buy1 + list[i], sell1);
    buy2 = Math.max(sell1 - list[i], buy2);
    sell2 = Math.max(buy2 + list[i], sell2);
  }
  return sell2;
}
// const prices3 = [3, 3, 5, 0, 0, 3, 1, 4];
// console.log("最多两次交易收益:", getMaxProfitByTwice(prices3)); // 输出: 6

function getMaxProfitUnlimit(k,list){
    const n=list.length
    if(k>=n/2){
        return getTotalMaxProfit(list)
    }
    const buy=new Array(k+1).fill(-list[0])
    const sell=new Array(k+1).fill(0)
    for(let i=1;i<n;i++){
        for(let j=1;j<=k;j++){
            // 第 j 次买入：取决于【上一次卖出后的余额】减去【今天价格】
            buy[j]=Math.max(buy[j],sell[j-1]-list[i])
            // 第 j 次卖出：取决于【本次买入后的余额】加上【今天价格】
            sell[j]=Math.max(sell[j],buy[j]+list[i])
        }
    }
    return sell[k]
}
// 示例：限制最多交易 2 次
const k = 5;
const prices = [6, 5, 4, 3, 2, 1];
console.log(`最多交易 ${k} 次的最大收益:`, getMaxProfitUnlimit(k, prices)); // 输出: 7

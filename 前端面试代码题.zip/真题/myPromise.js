/*
 * @Desc:
 * @Author: SR
 * @Date: 2025-12-16 21:37:34
 */
const PENDING = "pending";
const FULFILLED = "fullfilled";
const REJECTED = "rejected";

class myPromise {
  constructor(executor) {
    this.state = PENDING;
    this.value = undefined;
    this.reason = undefined;

    this.onResolvedCallbacks = [];
    this.onRejectedCallbacks = [];

    const resolve = (value) => {
      if (this.state === PENDING) {
        this.state = FULFILLED;
        this.value = value;
        this.onResolvedCallbacks.forEach((fn) => fn());
      }
    };
    const reject = (reason) => {
      if (this.state === PENDING) {
        this.state = REJECTED;
        this.reason = reason;
        this.onRejectedCallbacks.forEach((fn) => fn());
      }
    };
    try {
      executor(resolve, reject);
    } catch (error) {
      reject(error);
    }
  }
  then(onFulfilled, onRejected) {
    onFulfilled = typeof onFulfilled === "function" ? onFulfilled : (value) => value;
    onRejected =
      typeof onRejected === "function"
        ? onRejected
        : (error) => {
            throw error;
          };
    let promise2 = new myPromise((resolve, reject) => {
      const handleCallback = (callback, stateData, resolveFn, rejectFn) => {
        setTimeout(() => {
          try {
            let x = callback(stateData);
            resolvePromise(promise2, x, resolveFn, rejectFn);
          } catch (e) {
            rejectFn(e);
          }
        }, 0);
      };
      if (this.state === FULFILLED) {
        handleCallback(onFulfilled, this.value, resolve, reject);
      }
      if (this.state === REJECTED) {
        handleCallback(onRejected, this.reason, resolve, reject);
      }
      if (this.state === PENDING) {
        this.onRejectedCallbacks.push(() => {
          handleCallback(onFulfilled, this.value, resolve, reject);
        });
        this.onRejectedCallbacks.push(() => {
          handleCallback(onRejected, this.reason, resolve, reject);
        });
      }
    });
    return promise2;
  }
}

function resolvePromise(promise2, x, resolve, reject) {
  if (promise2 === x) {
    return reject(new TypeError("Chainin cycle detected for promise"));
  }
  if (x !== null && (typeof x === "object" || typeof x === "function")) {
    let called = false;
    try {
      let then = x.then;
      if (typeof then === "function") {
        then.call(
          x,
          (y) => {
            if (called) return;
            called = true;
            resolvePromise(promise2, y, resolve, reject);
          },
          (r) => {
            if (called) return;
            called = true;
            reject(r);
          }
        );
      } else {
        resolve(x);
      }
    } catch (e) {
      if (called) return;
      called = true;
      reject(e);
    }
  } else {
    resolve(x);
  }
}

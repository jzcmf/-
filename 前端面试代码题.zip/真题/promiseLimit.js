/*
 * @Desc:
 * @Author: SR
 * @Date: 2025-12-02 17:23:02
 */
export function myPromiseLimit(tasks, limit) {
  return new Promise((resolve, reject) => {
    const len = tasks.length;
    if (!len) {
      resolve([]);
    }
    if (limit <= 0) {
      reject(new Error("limit must > 0!"));
    }
    const results = new Array(len);
    let running = 0; //用于打印
    let index = 0;
    let completed = 0;
    const taskRun = () => {
      if (index >= len) return;
      const currentIndex = index;//必须存储起来
      const task = tasks[currentIndex];
      index++;
      running++;
      task()
        .then((res) => {
          results[currentIndex] = res;
        })
        .catch((err) => {
          results[currentIndex] = err;
        })
        .finally(() => {
          running--;
          completed++;
          if (index < len) taskRun();
          if (completed === len) {
            resolve(results);
          }
        });
    };
    let start = Math.min(len, limit);
    for (let i = 0; i < start; i++) {
      taskRun();
    }
  });
}

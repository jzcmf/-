/*
 * @Desc:
 * @Author: SR
 * @Date: 2025-11-27 11:32:18
 */
/* 
给定一个数组 prices，其中 prices[i] 表示某股票第 i 天的价格。假设你最多可以完成两笔交易（即买入和卖出一次为一笔交易），设计一个算法来计算你能获得的最大利润。
*/
const maxProfit = (prices) => {
  let b1 = -Infinity;
  let s1 = 0;
  let b2 = -Infinity;
  let s2 = 0;
  for (let i = 0; i < prices.length; i++) {
    b1 = Math.max(b1, -prices[i]);
    s1 = Math.max(s1, prices[i] + b1);
    b2 = Math.max(b2, s1 - prices[i]);
    s2 = Math.max(s2, prices[i] + b2);
  }
  return s2;
};
console.log("2次交易最大利润",maxProfit([3, 3, 5, 1, 1, 3, 1, 4]));

/* 
给定一个数组 prices，其中 prices[i] 表示某股票第 i 天的价格。假设你最多可以完成无限次交易（即买入和卖出一次为一笔交易），设计一个算法来计算你能获得的最大利润。
*/
const maxProfitMax = (prices) => {
  let total = 0;
  for (let i = 1; i < prices.length; i++) {
    if (prices[i] - prices[i - 1] > 0) {
      total += prices[i] - prices[i - 1];
    }
  }
  return total;
};
console.log("无限次交易最大利润", maxProfitMax([1,2,3,4,5]));

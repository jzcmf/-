let activeReactiveFn = null;
const targetMap = new WeakMap();
let color = "blue";
class Depend {
  constructor() {
    this.reactiveFns = new Set();
  }
  depend() {
    if (!activeReactiveFn) return;
    this.reactiveFns.add(activeReactiveFn);//收集多个依赖
  }
  notify() {
    this.reactiveFns.forEach((fn) => fn());
  }
}

function getDepend(target, key) {
  let map = targetMap.get(target);
  if (!map) {
    map = new Map();
    targetMap.set(target, map);
  }
  let depend = map.get(key);
  if (!depend) {
    depend = new Depend();
    map.set(key, depend);
  }
  return depend;
}

function reactive(obj) {
  return new Proxy(obj, {
    get: function (target, key, receiver) {
      const depend = getDepend(target, key);
      depend.depend();
      return Reflect.get(target, key, receiver);
    },
    set: function (target, key, receiver) {
      let result = Reflect.set(target, key, receiver);
      const depend = getDepend(target, key);
      depend.notify();
      return result;
    },
  });
}
const isObject=(val)=>{
    return val!==null&&typeof val==='object'
}
function ref(rawValue){
    if(rawValue&&rawValue.__isRef) return rawValue
    let _value=isObject(rawValue)?reactive(rawValue):rawValue
    let r={
        __isRef:true,
        get value(){
            const depend=getDepend(r,'value')
            depend.depend()
            return _value
        },
        set value(newValue){
            _value=isObject(newValue)?reactive(newValue):newValue;
            const depend=getDepend(r,'value')
            depend.notify()
        }
    }
    return r
}

function watchFn(fn) {
  activeReactiveFn = fn;
  fn();
  activeReactiveFn = null;
}
//例
const info = reactive({
  age: 18,
  name: "lily",
});
watchFn(() => console.log(info.name));
info.name = "many";
const company=ref('keystar')
watchFn(()=>console.log(company.value)
)
company.value='new keystar'
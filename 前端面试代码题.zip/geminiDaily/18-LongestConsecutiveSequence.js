/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-02-03 14:30:49
 */
/**
 * @description 给定一个未排序的整数数组 nums ，找出数字连续的最长序列（不要求序列元素在原数组中连续）的长度。
 * @param {number[]} nums
 * @return {number}
 */

//不符合
// var longestConsecutive = function (nums) {
//   // 要求：O(N) 时间复杂度
//   // 提示：先 new Set(nums) 去重且方便查找
//   const mySet = new Set(nums);
//   let current = null;
//   let arr = [];
//   let maxLen = 1;
//   while (mySet.size > 1) {
//     current = Math.min(...mySet);
//     arr = [current];
//     while (mySet.has(current + 1)) {
//       current = current + 1;
//       arr.push(current);
//     }
//     maxLen = Math.max(arr.length, maxLen);
//     arr.forEach((item) => mySet.delete(item));
//   }
//   return maxLen;
// };
// const a = [1, 2, 6, 3, -1, 5, 4, 8, 7];
// console.log(longestConsecutive(a));

var longestConsecutive = (nums) => {
  const numSet = new Set(nums);
  let longestLen = 0;
  for (let num of numSet) {
    if (!numSet.has(num - 1)) {
      let currentNum = num;
      let currentLen = 1;
      while (numSet.has(currentNum + 1)) {
        currentNum++;
        currentLen++;
      }
      longestLen = Math.max(longestLen, currentLen);
    }
  }
  return longestLen;
};
const a = [1, 2, 6, 3, -1, 5, 4, 8, 7];
console.log(longestConsecutive(a));

//返回最长递增子序列长度,list中排序是相对按序的，vue3中就是使用该方法比对新旧树
const LST = (list) => {
  let maxLen = 0;
  if (!list.length) return maxLen;
  const dp = list.map((item) => 1);
  for (let i = 1; i < list.length; i++) {
    for (let j = 0; j < i; j++) {
      if (list[i] > list[j]) {
        dp[i] = Math.max(dp[i], dp[j] + 1);
      }
    }
    maxLen = Math.max(maxLen, dp[i]);
  }
  return maxLen;
};
//返回最长递增子序列数组,list中排序是相对按序的，vue3中就是使用该方法比对新旧树
const getLstResult = (list) => {
  let maxLst = [];
  const n = list.length;
  if (n === 0) return maxLst;
  // 默认最长的子序列至少包含第一个元素
  maxLst = [list[0]];
  const dp = list.map((item) => [item]);
  for (let i = 1; i < n; i++) {
    for (let j = 0; j < i; j++) {
      if (list[i] > list[j]) {
        dp[i] = dp[i].length > dp[j].length + 1 ? dp[i] : [...dp[j], list[i]];
      }
    }
    maxLst = maxLst.length > dp[i].length ? maxLst : dp[i];
  }
  return maxLst;
};
console.log("get max lst:", getLstResult([-1, 2, 6, 3, 4, 8, 9,1,7,10,0,11,12,13,14]));

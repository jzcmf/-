/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-01-30 14:21:32
 */
var MyQueue = function () {
  this.inStack = []; // 专门负责进
  this.outStack = []; // 专门负责出
};

/** * @param {number} x
 * @return {void}
 */
MyQueue.prototype.push = function (x) {
  // 你的代码
  this.inStack.push(x);
};

/** * @return {number}
 */
MyQueue.prototype.pop = function () {
  // 提示：如果 outStack 为空，要把 inStack 里的东西全搬过来
  if (this.outStack.length === 0) {
    while (this.inStack.length) {
      this.outStack.push(this.inStack.pop());
    }
  }
  return this.outStack.pop();
};

/** * @return {number}
 */
MyQueue.prototype.peek = function () {
  // 和 pop 逻辑类似，只是不移除
  if (!this.outStack.length) {
    while (this.inStack.length > 0) {
      this.outStack.push(this.inStack.pop());
    }
  }
  return this.outStack[this.outStack.length - 1];
};

/** * @return {boolean}
 */
MyQueue.prototype.empty = function () {
  // 两个栈都空了才是空
  return this.inStack.length === 0 && this.outStack.length === 0;
};

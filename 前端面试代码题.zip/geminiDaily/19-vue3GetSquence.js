/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-03-05 09:32:28
 */
//二分查找
var search = function (nums, target) {
  let left = 0;
  let right = nums.length - 1;

  // 当 left <= right 时，说明区间内还有数字可以找
  while (left <= right) {
    // 1. 算出中间位置 mid
    let mid = Math.floor((left + right) / 2);
    // 2. 如果刚好等于 target，直接 return mid
    if (nums[mid] === target) {
      return mid;
    }
    // 3. 如果比 target 小，说明在右边，left = ?
    if (nums[mid] < target) {
      left = mid + 1;
    }
    // 4. 如果比 target 大，说明在左边，right = ?
    if (nums[mid] > target) {
      right = mid - 1;
    }
  }

  // 如果把区间缩没了都没找到，说明不存在
  return -1;
};
/**
 * Vue3 源码中的 getSequence (简化变量名版)
 * @param {number[]} arr - 输入的数组 (例如: [2, 1, 5, 3, 6, 4, 8, 9, 7])
 * @return {number[]} - 返回最长递增子序列的索引数组
 */
function getSequence(arr) {
  const p = arr.slice(); // 存档点字典：用于回溯
  const result = [0]; // 存储递增子序列的索引（默认把第 0 个索引放进去）

  const len = arr.length;

  for (let i = 0; i < len; i++) {
    const arrI = arr[i];

    // Vue3 针对 DOM diff 的特殊逻辑：值为 0 代表新增节点，不参与 LIS 计算
    if (arrI !== 0) {
      // result 里的最后一个索引
      const j = result[result.length - 1];

      // 1. 贪心：如果当前值大于 result 最后一个索引对应的值
      if (arr[j] < arrI) {
        // 💡 TODO: 把谁的索引记作 p[i] 的前驱？
        // 💡 TODO: 把当前索引 i push 进 result
        p[i] = j;
        result.push(i);
        continue;
      }

      // 2. 二分查找：如果当前值比较小，找到 result 中第一个大于等于 arrI 的值的位置
      let start = 0;
      let end = result.length - 1;
      while (start < end) {
        // 💡 TODO: 标准二分查找找左侧边界
        let mid = Math.floor((left + right) / 2);
        if (arr[result[mid]] < arrI) {
          start = mid + 1;
        } else {
          end = mid;
        }
      }

      // 3. 替换与存档
      if (arrI < arr[result[start]]) {
        // 💡 TODO: 存档：记录 p[i] 的前驱节点是 result[start - 1]
        // 💡 TODO: 替换：result[start] = i
        if (start > 0) {
          p[i] = result[start - 1];
          result[start] = i;
        }
      }
    }
  }

  // 4. 回溯修正 (Backtracking)
  // 这一步是精华！利用 p 数组，从 result 的最后一个元素往前回溯，覆盖正确的索引。
  let u = result.length;
  let v = result[u - 1];
  while (u-- > 0) {
    result[u] = v;
    v = p[v];
  }

  return result;
}

console.log(getSequence([2, 1, 5, 3, 6, 4, 8, 9, 7]));
// 期望输出索引: [1, 3, 5, 6, 7] (对应的值是: 1, 3, 4, 8, 9)

/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-01-27 16:33:23
 */
/**
 * Definition for singly-linked list.
 * function ListNode(val, next) {
 * this.val = (val===undefined ? 0 : val)
 * this.next = (next===undefined ? null : next)
 * }
 */
/**
 * @param {ListNode} list1
 * @param {ListNode} list2
 * @return {ListNode}
 */
var mergeTwoLists = function (list1, list2) {
  // 💡 提示：先 new ListNode(-1) 作为 dummy
  // 然后用 while 循环比较 list1.val 和 list2.val
  let dummy = new ListNode(-1);
  let current=dummy
  while (list1 && list2) {
    if (list2.val > list1.val) {
      current.next = list1;
      list1 = list1.next;
    } else {
      current.next = list2;
      list2 = list2.next;
    }
    current=current.next
  }
  current.next = list1 ?? list2;
  return dummy.next;
};

/*
 * @Desc: 
    // 1. 创建一个 Map
    // 2. 遍历 nums
    // 3. 计算需要的另一半： complement = target - num
    // 4. 查表：map 里有 complement 吗？
    //    - 有：返回 [map.get(complement), 当前下标]
    //    - 无：把 [num, 当前下标] 存进 map
    
 * @Author: SR
 * @Date: 2026-01-30 14:59:54
 */
/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number[]}
 */
var twoSum = function (nums, target) {
  const sumMap = new Map();
  for (let i = 0; i < nums.length; i++) {
    let otherNum = target - nums[i];
    if (sumMap.has(otherNum)) {
      return [i, sumMap.get(otherNum)];
    } else {
      sumMap.set(nums[i], i);
    }
  }
  return [];
};

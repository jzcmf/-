/**
 * @param {ListNode} head
 * @param {number} n
 * @return {ListNode}
 */
var removeNthFromEnd = function (head, n) {
  // 1. 初始化 dummy
  // 2. 快指针先走 n 步 (或者 n+1)
  // 3. 快慢指针同速前进
  // 4. 修改指针指向
  let dummy = new ListNode(-1);
  dummy.next = head;
  let fast = dummy;
  let slow = dummy;
  let step = n + 1;
  while (fast) {
    fast = fast.next;
    if (step === 0) {
      slow = slow.next;
    } else {
      step--;
    }
  }
  slow.next = slow.next.next;
  return dummy.next;
};

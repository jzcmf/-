/* 
📅 Day 15：有效的字母异位词 (Valid Anagram)
难度评级：⭐⭐ (Easy) 标签：Hash Table String Counter

📝 题目描述
给定两个字符串 s 和 t ，编写一个函数来判断 t 是否是 s 的字母异位词。

什么叫“字母异位词”？ 就是两个单词的字母完全一样（每个字母出现的次数也一样），只是顺序不同。 （比如 "rat" 和 "tar"，或者 "listen" 和 "silent"）。
 */
/**
 * @param {string} s
 * @param {string} t
 * @return {boolean}
 */
var isAnagram = function (s, t) {
  // 1. 长度不同直接 false
  // 2. 创建一个 map 或 obj
  // 3. 遍历 s 加分
  // 4. 遍历 t 减分 (一旦减到小于0，说明 t 里的这个字母比 s 多，直接 false)
  // 5. 如果全过程都很顺利，最后 return true
  if (s.length !== t.length) {
    return false;
  }
  const charMap = new Map();
  for (let char of s) {
    let n = (charMap.get(char) ?? 0) + 1;
    charMap.set(char, n);
  }
  for (let char of t) {
    let n = (charMap.get(char) ?? 0) - 1;
    if (n < 0) {
      return false;
    }
    charMap.set(char, n);
  }
  return true;
};

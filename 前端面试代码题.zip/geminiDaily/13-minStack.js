/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-01-29 11:30:18
 */
var MinStack = function () {
  this.stack = []; // 主栈
  this.min_stack = []; // 辅助栈
};

/** * @param {number} val
 * @return {void}
 */
MinStack.prototype.push = function (val) {
  // 你的代码
  this.stack.push(val);
  if (!this.min_stack.length || val < this.min_stack[this.min_stack.length - 1]) {
    this.min_stack.push(val);
  } else {
    this.min_stack.push(this.min_stack[this.min_stack.length - 1]);
  }
};

/** * @return {void}
 */
MinStack.prototype.pop = function () {
  // 你的代码
  this.min_stack.pop();
  return this.stack.pop();
};

/** * @return {number}
 */
MinStack.prototype.top = function () {
  // 你的代码
  if (this.stack.length) {
    return this.stack[this.stack.length - 1];
  } else {
    return null;
  }
};

/** * @return {number}
 */
MinStack.prototype.getMin = function () {
  // 你的代码
  if (this.min_stack.length) {
    return this.min_stack[this.min_stack.length - 1];
  } else {
    return null;
  }
};

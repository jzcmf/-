/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-01-27 16:28:02
 */
//环形链表检测
/**
 * Definition for singly-linked list.
 * function ListNode(val) {
 * this.val = val;
 * this.next = null;
 * }
 */

/**
 * @param {ListNode} head
 * @return {boolean}
 */
var hasCycle = function (head) {
  // 你的代码
  if (!head) return false;
  let fast = head;
  let slow = head;
  while (fast && fast.next) {
    fast = fast.next.next;
    slow = slow.next;
    if (fast === slow) {
      //如果fast不为null时与slow相等，证明fast指针已经进入环中追上slow
      return true;
    }
  }
  return false;
};

/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-01-28 15:28:26
 */
// 给定一个只包括 '('，')'，'{'，'}'，'['，']' 的字符串 s ，判断字符串是否有效。

// 有效字符串需满足：

// 左括号必须用相同类型的右括号闭合。

// 左括号必须以正确的顺序闭合。

// 每个右括号都有一个对应的相同类型的左括号。
/**
 * @param {string} s
 * @return {boolean}
 */
var isValid = function (s) {
  // 1. 创建一个 map 存配对关系 (建议 key 是右括号, value 是左括号)
  // 2. 创建 stack 数组
  // 3. 遍历 s ...
  const map = new Map([
    [")", "("],
    ["}", "{"],
    ["]", "["],
  ]);
  const stack = [];
  for (let char of s) {
    if (map.has(char)) {
      const topChar = stack.pop();
      if (topChar !== map.get(char)) {
        return false;
      }
    } else {
        stack.push(char)
    }
  }
  return stack.length === 0;
};

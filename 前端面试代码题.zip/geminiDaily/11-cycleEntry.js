/**
 * @param {ListNode} head
 * @return {ListNode}
 */
//找出链表中是否有环，如果有环要找到环入口
var detectCycle = function (head) {
  // 1. 快慢指针找相遇点
  // 2. 如果没相遇（无环），return null
  // 3. 重置其中一个指针到 head
  // 4. 两个指针同速前进，直到再次相遇
  let fast = head;
  let slow = head;
  while (fast && fast.next) {
    fast = fast.next.next;
    slow = slow.next;
    if (fast === slow) {
      slow = head;
      while (fast !== slow) {
        fast = fast.next;
        slow = slow.next;
      }
      return slow;
    }
  }
  return null;
};

/*
 * @Desc: 
 * @Author: SR
 * @Date: 2026-01-23 14:08:33
 */
/* 
    node:{
        value:number,
        left:node,
        right:node
    }
*/
//遍历二叉树，返回每一层的节点值
function levelTree(root) {
  if (!root) return [];
  const result = [];
  const queue = [root];
  while (queue.length > 0) {
    const currentLevelSize = queue.length;
    const currentArr = [];
    for (let i = 0; i < currentLevelSize; i++) {
      let node = queue.shift();
      currentArr.push(node.value);
      if (node.left) {
        queue.push(node.left);
      }
      if (node.right) {
        queue.push(node.right);
      }
    }
    result.push(currentArr)
  }
  return result
}

/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-02-03 11:52:15
 */
/**
 * @description 字母异位词分组
 * @param {string[]} strs
 * @return {string[][]}
 */
var groupAnagrams = function (strs) {
  const charMap = new Map();
  const getStrKey = (str) => {
    return str.split("").sort().join("");
  };
  strs.forEach((item) => {
    let key = getStrKey(item);
    if (charMap.has(key)) {
      const arr = charMap.get(key);
      arr.push(item);
    } else {
      charMap.set(key, [item]);
    }
  });
  return [...charMap.values()];
};
console.log(groupAnagrams(["eat", "tea", "tan", "ate", "nat", "bat"]));

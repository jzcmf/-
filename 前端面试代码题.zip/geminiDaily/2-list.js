/*
 * @Desc:
 * @Author: SR
 * @Date: 2026-01-26 11:37:52
 */
/**
 * Definition for singly-linked list.
 * function ListNode(val, next) {
 * this.val = (val===undefined ? 0 : val)
 * this.next = (next===undefined ? null : next)
 * }
 */
/**
 * @param {ListNode} head
 * @return {ListNode}
 */
//反转列表
var reverseList = function (head) {
  let currNode = head;
  let prevNode = null;
  // 你的代码
  while (currNode) {
    let temp = currNode.next;
    currNode.next = prevNode;
    prevNode = currNode;
    currNode = temp;
  }
  return prevNode;
};


